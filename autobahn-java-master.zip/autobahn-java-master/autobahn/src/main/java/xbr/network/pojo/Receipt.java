package xbr.network.pojo;

public class Receipt {
    public byte[] remaining;
    public int channel_seq;
    public byte[] signature;
    public byte[] sealed_key;
}
